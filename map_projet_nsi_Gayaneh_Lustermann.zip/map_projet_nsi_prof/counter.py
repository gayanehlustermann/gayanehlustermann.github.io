class counter_double_key(object):
	def __init__(self, name):
		self.count_dict = {}
		self.name = name

	def count(self, country, dest):
		if country in self.count_dict:
			if dest in self.count_dict[country]:
				self.count_dict[country][dest] += 1
			else:
				self.count_dict[country][dest] = 1
		else:
			self.count_dict[country] = {}
			self.count_dict[country][dest] = 1


class counter_single_key(object):
	def __init__(self, name):
		self.count_dict = {}
		self.name = name

	def count(self, country):
		if country in self.count_dict:
			self.count_dict[country] += 1
		else:
			self.count_dict[country] = 1

	def get_value_list(self):
		value_list = []
		for key, val in self.count_dict.items():
			value_list.append({'x':key, 'y':val})

		return value_list