# importing the csv for the teachers - test

import csv
import folium 

from chart_templates import *
from pays_infos import *
from counter import *

print(empty_teacher_chart)
#




# counnt info concerning teachers erasmus echange

# how often a teach from a given  country went into which other country
teachers_host_dest_counter = counter_double_key('profs_erasmus')
students_host_dest_counter = counter_double_key('students_erasmus')

teachers_homes = counter_single_key('teachers_erasmus_homes')
teachers_hosts = counter_single_key('teachers_erasmus_dests')

students_homes = counter_single_key('students_erasmus_homes')
students_dests = counter_single_key('students_erasmus_dests')



with open('profs_erasmus.csv',encoding='utf-8') as csv_file:
	csv_reader = csv.reader(csv_file,delimiter=';')
	next(csv_reader)
	for i, line in enumerate(csv_reader):
		#l = [entry.encode('utf-8') for entry in line]

		if len(line) == 25:
			home, gender, nationality, host = line[1], line[8], line[9],line[13] 

			# combine three different country codes for Belgium
			if home == 'BEDE' or home =='BENL' or home == 'BEFR':
				home = 'BE'

			if host == 'BEDE' or host =='BENL' or host == 'BEFR':
				host = 'BE'

			teachers_host_dest_counter.count(home, host)
			teachers_homes.count(home)
			teachers_hosts.count(host)
			
			#print(i,len(line), home, gender, nationality, host)
print('teachers data read')


print('reading students data')
with open('students_erasmus.csv',encoding='utf-8') as csv_file:
	csv_reader = csv.reader(csv_file,delimiter=';')
	next(csv_reader)
	for i, line in enumerate(csv_reader):
		#l = [entry.encode('utf-8') for entry in line]

		# if i%1000 == 0:
		# 	print('len(line)',i, len(line))

		if len(line) == 32:
			home, gender, nationality, host, country_of_placement = \
			line[1], line[3], line[4], line[10], line[12]

			# destination country of studenst is either host  (if they study) or
			# country_of_placement if they go for an internship
			if host == '':
				dest = country_of_placement
			else:
				dest = host

			# combine threedifferen country codes for Belgium
			if home == 'BEDE' or home =='BENL' or home == 'BEFR':
				home = 'BE'

			if dest == 'BEDE' or dest =='BENL' or dest == 'BEFR':
				dest = 'BE'

			students_host_dest_counter.count(home, dest)
			students_homes.count(home)
			students_dests.count(dest)
			
			#print(i,len(line), home, gender, nationality, host)

#print(students_host_dest_counter)		
print('done')



# create popup charts per country for teachers destination
teacher_charts = {}
teacher_charts_values = {}

for key_home, val_home in teachers_host_dest_counter.count_dict.items():

	value_list_T = []
	for key_dest, val_dest in teachers_host_dest_counter.count_dict[key_home].items():

		value_list_T.append({'xx':key_dest, 'yy':val_dest})

	teacher_charts_values[key_home] = value_list_T
	teacher_charts[key_home] = dict(empty_teacher_chart)
	# print(key_home)
	# print(value_list)
	# print(teacher_charts[key_home])
	teacher_charts[key_home]['data'] = {'values':value_list_T}
	teacher_charts[key_home]['title'] = teacher_charts[key_home]['title'] + ' ' + key_home

student_charts = {}
student_charts_values = {}

for key_home, val_home in students_host_dest_counter.count_dict.items():

	value_list_S = []
	for key_dest, val_dest in students_host_dest_counter.count_dict[key_home].items():

		value_list_S.append({'x':key_dest, 'y':val_dest})

	student_charts_values[key_home] = value_list_S
	student_charts[key_home] = dict(empty_student_chart)
	# print(key_home)
	# print(value_list)
	# print(teacher_charts[key_home])
	student_charts[key_home]['data'] = {'values':value_list_S}
	student_charts[key_home]['title'] = student_charts[key_home]['title'] + ' ' + key_home


# value_list_students_homes = []
# value_list_students_dests = []

# value_list_students_homes = students_homes.get_value_list()
# value_list_students_dests = students_dests.get_value_list()

teachers_homes_chart = dict(empty_chart)
teachers_homes_chart['data'] = {'values':teachers_homes.get_value_list()}

teachers_hosts_chart = dict(empty_chart)
teachers_hosts_chart['data'] = {'values':teachers_hosts.get_value_list()}


students_homes_chart = dict(empty_chart)
students_homes_chart['data'] = {'values':students_homes.get_value_list()}

students_dests_chart = dict(empty_chart)
students_dests_chart['data'] = {'values':students_dests.get_value_list()}


# for key, val in students_homes.count_dict[key].items():

# 	value_list_students_homes.append({'x':key, 'y':val})

# for key, val in students_dests.count_dict[key].items():

# 	value_list_students_dests.append({'x':key, 'y':val})


# Create Map

startGPS = coordonnees_europe


erasmus_mobility_map = folium.Map(
 	location= startGPS,
 	zoom_start=2,
 	tiles ='Stamen Terrain'
)

shift_longitude = 0.7
shift_latitude = 0.7

for key, value in teacher_charts.items():

	# slightly shift marker longitude
	loc = coordonnees_pays[key]
	loc[1] += shift_longitude

	folium.Marker( 
		location=loc,
		#location[1] = location[1] + shift_longitude
		popup=folium.Popup().add_child(folium.VegaLite(teacher_charts[key])), 
		tooltip='professeur: ' + key
		).add_to(erasmus_mobility_map) 


for key, value in student_charts.items():


	loc = coordonnees_pays[key]
	loc[1] -= shift_longitude
	folium.Marker( 
		location=loc,
		#location[1] = location[1] - shift_longitude
		popup=folium.Popup().add_child(folium.VegaLite(student_charts[key])),
		tooltip='students: ' + key
		).add_to(erasmus_mobility_map) 

loc = coordonnees_europe
loc[1] += shift_longitude

folium.Marker( 
	location=loc,
	popup=folium.Popup().add_child(folium.VegaLite(students_homes_chart)), 
	tooltip='students homes - ALL'
	).add_to(erasmus_mobility_map) 

loc[1] -= 2 * shift_longitude
folium.Marker( 
	location=loc ,
	popup=folium.Popup().add_child(folium.VegaLite(students_dests_chart)),
	tooltip='students dests - ALL' 
	).add_to(erasmus_mobility_map)

loc[0] += shift_latitude

folium.Marker( 
	location=loc,
	popup=folium.Popup().add_child(folium.VegaLite(teachers_homes_chart)), 
	tooltip='teachers homes - ALL'
	).add_to(erasmus_mobility_map) 

loc[0] -= 2 * shift_longitude
folium.Marker( 
	location=loc ,
	popup=folium.Popup().add_child(folium.VegaLite(teachers_hosts_chart)),
	tooltip='teachers dests - ALL' 
	).add_to(erasmus_mobility_map) 




erasmus_mobility_map.save('map_projet_nsi.html')
