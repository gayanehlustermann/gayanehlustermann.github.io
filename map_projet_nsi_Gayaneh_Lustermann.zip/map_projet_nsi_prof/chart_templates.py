

empty_teacher_chart = {
"$schema": "https://vega.github.io/schema/vega-lite/v4.json",
"description": "Empty chart templates for popup teacher/students", 
"title":"Erasmus data professeur",
"data":{}, 
  "mark": "bar",
  "encoding": {
  	"x": {
  		"field": "xx", 
  		"type": "nominal", 
  		"axis": {"title": "destinations"},
  		"sort": "-y"
  	},
  	"y": {
  		"field": "yy", 
  		"type": "quantitative", 
  		"axis": {"title": "nombre de personnes"}
  	},
  }
}


empty_student_chart = {
"$schema": "https://vega.github.io/schema/vega-lite/v4.json",
"description": "Empty chart templates for popup teacher/students",
"title":"Erasmus data eleves", 
"data":{}, 
  "mark": "bar",
  "encoding": {
  	"x": {
  		"field": "x", 
  		"type": "nominal",
  		"axis": {"title": "destinations"},
  		"sort":"-y"
  	},
  	"y": {
  		"field": "y", 
  		"type": "quantitative",
  		"axis": {"title": "nombre de personnes"}
  	}
  }
}

empty_chart = {
"$schema": "https://vega.github.io/schema/vega-lite/v4.json",
"description": "Empty chart templates for popup teacher/students",
"title":"Erasmus overall data", 
"data":{}, 
  "mark": "bar",
  "encoding": {
  	"x": {
  		"field": "x", 
  		"type": "nominal",
  		"axis": {"title": "destinations"},
  		"sort":"-y"
  	},
  	"y": {
  		"field": "y", 
  		"type": "quantitative",
  		"axis": {"title": "nombre de personnes"}
  	}
  }
}